#pragma once
class Point_2d
{
public:
	float x;
	float y;
public:
	void setPoint(const float&sx,const float&sy);
	//Point_2d&	operator=(const Point_2d& sp);
	Point_2d(void);
	~Point_2d(void);
};

