#include "stdafx.h"
#include "Point_2d.h"


void Point_2d::setPoint(const float& sx,const float& sy)
{
	x=sx;
	y=sy;
}

Point_2d::Point_2d(void)
{
	x=0.0f;
	y=0.0f;
}


Point_2d::~Point_2d(void)
{
}
