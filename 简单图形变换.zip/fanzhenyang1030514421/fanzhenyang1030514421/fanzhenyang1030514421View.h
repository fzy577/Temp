
// fanzhenyang1030514421View.h : Cfanzhenyang1030514421View ��Ľӿ�
//


#include "Transfer.h"
#pragma once
class Cfanzhenyang1030514421View : public CView
{
protected: // �������л�����
	Cfanzhenyang1030514421View();
	DECLARE_DYNCREATE(Cfanzhenyang1030514421View)

// ����
public:
	Cfanzhenyang1030514421Doc* GetDocument() const;
private:
	Transfer m_transfer;
	Point_2d p1;
	Point_2d p2;
	Point_2d p3;
// ����
public:

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ʵ��
public:
	virtual ~Cfanzhenyang1030514421View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	void mid_line(CDC* pDC, int x0, int y0, int x1, int y1);
	void init(void);
	afx_msg void On32771();
	afx_msg void On32772();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void On32773();
};

#ifndef _DEBUG  // fanzhenyang1030514421View.cpp �еĵ��԰汾
inline Cfanzhenyang1030514421Doc* Cfanzhenyang1030514421View::GetDocument() const
   { return reinterpret_cast<Cfanzhenyang1030514421Doc*>(m_pDocument); }
#endif

