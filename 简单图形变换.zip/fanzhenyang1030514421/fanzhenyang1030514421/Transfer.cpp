//**************************************************//
//                  Transfer.cpp
//�������������������任���ʵ��
//
//                                    by ��ݮ1404
//                                    2016 - 5 - 10 
//**************************************************//



#include "stdafx.h"
#include "Transfer.h"
#include <math.h>


Transfer::Transfer(void)
{
}


Transfer::~Transfer(void)
{
}

//ƽ�Ʊ任
Point_2d Transfer::Translation(Point_2d p,float Tx,float Ty)
{
	Point_2d q;
	q.x=p.x+Tx;
	q.y=p.y+Ty;
	return q;
}

//�����任
Point_2d Transfer::Scale(Point_2d p,float Sx,float Sy,float x0,float y0)
{

	Point_2d q;
	double a[3][3];
	a[0][0]=1;a[0][1]=0;a[0][2]=0;
	a[1][0]=0;a[1][1]=1;a[1][2]=0;
	a[2][0]=-x0;a[2][1]=-y0;a[2][2]=1;//ƽ�Ƶ�ԭ��

	double c[3][3];
	c[0][0]=1;c[0][1]=0;c[0][2]=0;
	c[1][0]=0;c[1][1]=1;c[1][2]=0;
	c[2][0]=x0;c[2][1]=y0;c[2][2]=1;//��������

	double b[3][3];
	b[0][0]=Sx;b[0][1]=0;b[0][2]=0;
	b[1][0]=0;b[1][1]=Sy;b[1][2]=0;
	b[2][0]=0;b[2][1]=0;b[2][2]=1;//��������

	double o[3][3];
	double k[3][3];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			k[i][j]=a[i][0]*b[0][j]+a[i][1]*b[1][j]+a[i][2]*b[2][j];
		}
	}
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			o[i][j]=k[i][0]*c[0][j]+k[i][1]*c[1][j]+k[i][2]*c[2][j];
		}
	}
	q.x=p.x*o[0][0]+p.y*o[1][0]+1*o[2][0];
	q.y=p.x*o[0][1]+p.y*o[1][1]+1*o[2][1];
	//����˷�
	return q;
}

//��ת�任
Point_2d Transfer::Rotation(Point_2d p,float m,float x0,float y0)
{
	Point_2d q;
	double a[3][3];
	a[0][0]=1;a[0][1]=0;a[0][2]=0;
	a[1][0]=0;a[1][1]=1;a[1][2]=0;
	a[2][0]=-x0;a[2][1]=-y0;a[2][2]=1;//ƽ�Ƶ�ԭ��

	double c[3][3];
	c[0][0]=1;c[0][1]=0;c[0][2]=0;
	c[1][0]=0;c[1][1]=1;c[1][2]=0;
	c[2][0]=x0;c[2][1]=y0;c[2][2]=1;//��������

	double b[3][3];
	double w=3.1415*m;
	b[0][0]=cos(w);b[0][1]=sin(w);b[0][2]=0;
	b[1][0]=-sin(w);b[1][1]=cos(w);b[1][2]=0;
	b[2][0]=0;b[2][1]=0;b[2][2]=1;//��ת����

	double o[3][3];
	double k[3][3];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			k[i][j]=a[i][0]*b[0][j]+a[i][1]*b[1][j]+a[i][2]*b[2][j];
		}
	}
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			o[i][j]=k[i][0]*c[0][j]+k[i][1]*c[1][j]+k[i][2]*c[2][j];
		}
	}
		q.x=p.x*o[0][0]+p.y*o[1][0]+1*o[2][0];
		q.y=p.x*o[0][1]+p.y*o[1][1]+1*o[2][1];
			//����˷�
	return q;

}
