
// fanzhenyang1030514421View.cpp : Cfanzhenyang1030514421View ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "fanzhenyang1030514421.h"
#endif

#include "fanzhenyang1030514421Doc.h"
#include "fanzhenyang1030514421View.h"
#include "Point_2d.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cfanzhenyang1030514421View

IMPLEMENT_DYNCREATE(Cfanzhenyang1030514421View, CView)

BEGIN_MESSAGE_MAP(Cfanzhenyang1030514421View, CView)
	// ��׼��ӡ����
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &Cfanzhenyang1030514421View::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_32771, &Cfanzhenyang1030514421View::On32771)
	ON_COMMAND(ID_32772, &Cfanzhenyang1030514421View::On32772)
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEWHEEL()
	ON_COMMAND(ID_32773, &Cfanzhenyang1030514421View::On32773)
END_MESSAGE_MAP()

// Cfanzhenyang1030514421View ����/����

Cfanzhenyang1030514421View::Cfanzhenyang1030514421View()
{
	// TODO: �ڴ˴����ӹ������

}

Cfanzhenyang1030514421View::~Cfanzhenyang1030514421View()
{
}

BOOL Cfanzhenyang1030514421View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CView::PreCreateWindow(cs);
}

// Cfanzhenyang1030514421View ����

void Cfanzhenyang1030514421View::OnDraw(CDC* /*pDC*/)
{
	Cfanzhenyang1030514421Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: �ڴ˴�Ϊ�����������ӻ��ƴ���
}


// Cfanzhenyang1030514421View ��ӡ


void Cfanzhenyang1030514421View::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL Cfanzhenyang1030514421View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Ĭ��׼��
	return DoPreparePrinting(pInfo);
}

void Cfanzhenyang1030514421View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
}

void Cfanzhenyang1030514421View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӵ�ӡ����е���������
}

void Cfanzhenyang1030514421View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void Cfanzhenyang1030514421View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// Cfanzhenyang1030514421View ���

#ifdef _DEBUG
void Cfanzhenyang1030514421View::AssertValid() const
{
	CView::AssertValid();
}

void Cfanzhenyang1030514421View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

Cfanzhenyang1030514421Doc* Cfanzhenyang1030514421View::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(Cfanzhenyang1030514421Doc)));
	return (Cfanzhenyang1030514421Doc*)m_pDocument;
}
#endif //_DEBUG


// Cfanzhenyang1030514421View ��Ϣ��������


void Cfanzhenyang1030514421View::mid_line(CDC* pDC, int x0, int y0, int x1, int y1)
{
	int a,b,d1,d2,d,x,y;float m;
	if (x1<x0)
	{
		d=x0,x0=x1,x1=d;
		d=y0,y0=y1,y1=d;
	}  
	a=y0-y1,b=x1-x0;
	if (b==0) 
		m=-1*a*100;  
	else 
		m=(float)a/(x0-x1);x=x0,y=y0;  
	pDC->SetPixel(x,y,RGB(0,0,0));         
	if (m>=0 && m<=1)  
	{
		d=2*a+b;d1=2*a,d2=2*(a+b);  
		while (x<x1)  
		{  
			if (d<=0)    
			{   
				x++,y++,d+=d2;
			}  
			else   
			{  
				x++,d+=d1;  
			}  
			pDC->SetPixel(x,y,RGB(0,0,0));  
		}
	}  
	else if (m<=0 && m>=-1)  
	{
		d=2*a-b;d1=2*a-2*b,d2=2*a;  
		while (x<x1)  
		{  
			if (d>0) 
			{   
				x++,y--,d+=d1;
			}  
			else    
			{  
				x++,d+=d2;  
			}  
			pDC->SetPixel(x,y,RGB(0,0,0));  
		}  
	}  
	else if (m>1)  
	{
		d=a+2*b;d1=2*(a+b),d2=2*b;  
		while (y<y1)  
		{ 
			if (d>0) 
			{  
				x++,y++,d+=d1;
			}  
			else    
			{   
				y++,d+=d2;  
			}  
			pDC->SetPixel(x,y,RGB(0,0,0));  
		}  
	}  
	else  
	{
		d=a-2*b;d1=-2*b,d2=2*(a-b);      
		while (y>y1)  
		{  
			if (d<=0)    
			{  
				x++,y--,d+=d2;
			}  
			else   
			{ 
				y--,d+=d1; 
			}  
			pDC->SetPixel(x,y,RGB(0,0,0));  
		}
	}   
}


void Cfanzhenyang1030514421View::init(void)
{
	CDC* pDC=GetWindowDC();
	mid_line(pDC,300,300,400,400);
	mid_line(pDC,400,400,450,250);
	mid_line(pDC,450,250,300,300);
	static Point_2d p1;
	p1.x=300;p1.y=300;
	static Point_2d p2;
	p2.x=400;p2.y=400;
	static Point_2d p3;
	p3.x=450;p3.y=250;
	MessageBox(_T("��������ǰ���ȳ�ʼ�������������ƽ�ƣ�ͬʱ��ס���͡�����͡�������ת�任�������ֿ��ԷŴ���С��"));
}


void Cfanzhenyang1030514421View::On32771()
{
	// TODO: �ڴ�����������������
	p1.x=300;p1.y=300;
	p2.x=400;p2.y=400;
	p3.x=450;p3.y=250;
	init();
}


void Cfanzhenyang1030514421View::On32772()
{
	CDC* pDC=GetWindowDC();
	Point_2d p4=m_transfer.Translation(p1,0,100);
	Point_2d p5=m_transfer.Translation(p2,0,100);
	Point_2d p6=m_transfer.Translation(p3,0,100);

	Point_2d p7=m_transfer.Scale(p4,0.5,0.5,383,317);
	Point_2d p8=m_transfer.Scale(p5,0.5,0.5,383,317);
	Point_2d p9=m_transfer.Scale(p6,0.5,0.5,383,317);

	Point_2d p10=m_transfer.Rotation(p7,0.5,383,317);
	Point_2d p11=m_transfer.Rotation(p8,0.5,383,317);
	Point_2d p12=m_transfer.Rotation(p9,0.5,383,317);
	mid_line(pDC,p10.x,p10.y,p11.x,p11.y);
	mid_line(pDC,p11.x,p11.y,p12.x,p12.y);
	mid_line(pDC,p12.x,p12.y,p10.x,p10.y);
	// TODO: �ڴ�����������������
}


void Cfanzhenyang1030514421View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CDC* pDC=GetWindowDC();
	Point_2d p4;
	Point_2d p5;
	Point_2d p6;
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	Invalidate();
	switch (nChar)
	{
	case VK_UP:
		UpdateWindow();
		 if (GetAsyncKeyState(VK_LEFT)) 
		 {
			 p4=m_transfer.Rotation(p1,0.1,383,317);
			 p5=m_transfer.Rotation(p2,0.1,383,317);
			 p6=m_transfer.Rotation(p3,0.1,383,317);
			 mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
			 mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
			 mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
			 p1=p4;
			 p2=p5;
			 p3=p6;
		 }
		 else if (GetAsyncKeyState(VK_RIGHT))
		 {
			 p4=m_transfer.Rotation(p1,-0.1,383,317);
			 p5=m_transfer.Rotation(p2,-0.1,383,317);
			 p6=m_transfer.Rotation(p3,-0.1,383,317);
			 mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
			 mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
			 mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
			 p1=p4;
			 p2=p5;
			 p3=p6;
		 }
		 else
		 {
			p4=m_transfer.Translation(p1,0,-5);
			p5=m_transfer.Translation(p2,0,-5);
			p6=m_transfer.Translation(p3,0,-5);
			mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
			mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
			mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
			p1=p4;
			p2=p5;
			p3=p6;
		 }
		break;
	case VK_DOWN:
		UpdateWindow();
		p4=m_transfer.Translation(p1,0,5);
		p5=m_transfer.Translation(p2,0,5);
		p6=m_transfer.Translation(p3,0,5);
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
		p1=p4;
		p2=p5;
		p3=p6;
		break;
	case VK_LEFT:
		UpdateWindow();
		p4=m_transfer.Translation(p1,-5,0);
		p5=m_transfer.Translation(p2,-5,0);
		p6=m_transfer.Translation(p3,-5,0);
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
		p1=p4;
		p2=p5;
		p3=p6;
		break;
	case VK_RIGHT:
		UpdateWindow();
		p4=m_transfer.Translation(p1,5,0);
		p5=m_transfer.Translation(p2,5,0);
		p6=m_transfer.Translation(p3,5,0);
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
		p1=p4;
		p2=p5;
		p3=p6;
		break;
	default:
		break;
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}






void Cfanzhenyang1030514421View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	SetFocus();
	CView::OnLButtonDown(nFlags, point);
}


BOOL Cfanzhenyang1030514421View::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CDC* pDC=GetWindowDC();
	Point_2d p4;
	Point_2d p5;
	Point_2d p6;
	Invalidate();
	switch (zDelta)
	{
	case 120:
		UpdateWindow();
		p4=m_transfer.Scale(p1,0.5,0.5,383,317);
		p5=m_transfer.Scale(p2,0.5,0.5,383,317);
		p6=m_transfer.Scale(p3,0.5,0.5,383,317);
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
		p1=p4;
		p2=p5;
		p3=p6;
		break;
	case -120:
		UpdateWindow();
		p4=m_transfer.Scale(p1,2,2,383,317);
		p5=m_transfer.Scale(p2,2,2,383,317);
		p6=m_transfer.Scale(p3,2,2,383,317);
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p4.x,p4.y);
		p1=p4;
		p2=p5;
		p3=p6;
		break;
	default:
		break;
	}
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}


void Cfanzhenyang1030514421View::On32773()
{
	// TODO: �ڴ�����������������
	CDC* pDC=GetWindowDC();
	Point_2d p4;
	p4.x=200;p4.y=200;
	Point_2d p5;
	p5.x=250;p5.y=200-50*1.732;
	Point_2d p6;
	p6.x=350;p6.y=200-50*1.732;
	Point_2d p7;
	p7.x=400;p7.y=200;
	Point_2d p8;
	p8.x=350;p8.y=200+50*1.732;
	Point_2d p9;
	p9.x=250;p9.y=200+50*1.732;
	Point_2d p10;
	Point_2d p11;
	Point_2d p12;
	float m=0.01;
	for (;m<2;m=m+0.01)
	{
		mid_line(pDC,p4.x,p4.y,p5.x,p5.y);
		mid_line(pDC,p5.x,p5.y,p6.x,p6.y);
		mid_line(pDC,p6.x,p6.y,p7.x,p7.y);
		mid_line(pDC,p7.x,p7.y,p8.x,p8.y);
		mid_line(pDC,p8.x,p8.y,p9.x,p9.y);
		mid_line(pDC,p9.x,p9.y,p4.x,p4.y);
		p4=m_transfer.Rotation(p4,m,210,200);
		p5=m_transfer.Rotation(p5,m,210,200);
		p6=m_transfer.Rotation(p6,m,210,200);
		p7=m_transfer.Rotation(p7,m,210,200);
		p8=m_transfer.Rotation(p8,m,210,200);
		p9=m_transfer.Rotation(p9,m,210,200);

	}
}
